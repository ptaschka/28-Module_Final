e_mail = 'ptaschkaa@mail.ru'
passw = '5986KJs+p'
url_tmall = 'https://promotion.aliexpress.ru/wow/gcp/aer/channel/aer/tmall_localization/7pcZWCh8tW?wh_weex=true&_immersiveMode=true&wx_navbar_hidden=true&wx_navbar_transparent=true&ignoreNavigationBar=true&wx_statusbar_hidden=true'
url_tmall_login = 'https://login.aliexpress.ru/?spm=a2g0o.tm800006433.1000002.8.79447bdahOI4JN&return=https%3A%2F%2Fpromotion.aliexpress.ru%2Fwow%2Fgcp%2Faer%2Fchannel%2Faer%2Ftmall_localization%2F7pcZWCh8tW%3Fwh_weex%3Dtrue%26_immersiveMode%3Dtrue%26wx_navbar_hidden%3Dtrue%26wx_navbar_transparent%3Dtrue%26ignoreNavigationBar%3Dtrue%26wx_statusbar_hidden%3Dtrue&from=lighthouse&_ga=2.99074071.860221660.1661335962-97480273.1661335962'
def generate_string(n):
   return "x" * n

def russian_chars():
   return 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя'

def chinese_chars():
   return '的一是不了人我在有他这为之大来以个中上们'

def special_chars():
   return '|\\/!@#$%^&*()-_=+`~?"№;:[]{}'